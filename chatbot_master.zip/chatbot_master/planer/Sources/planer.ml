open Printf


class t  (model:string) (actions:string) (goal:string) (sport:string) (encoding:int)  =
object (self)


method search = (* notimed_search + *)

let lines = ref [] in 
let tempo_actions = ref [] in 
let linesper = ref [] in 
let linesperx = ref [] in 
let rtn = ref "" in
let filter_list = ref "" in
let action_danger = ref "" in 
let ideal_option = ref "" in 
let ideal_option_danger = ref "" in 
let ideal_sport = ref "" in 
let explanation = ref [] in 
let final_explanation = ref "" in 
let psize = ref 0 in 

let command cmd =
  Sys.command cmd
in


let filemodel = "../sdata/"^model in
let fileactions = "../sdata/"^actions in
let filegoal = "../sdata/"^goal in
let opt = sport in
let fileoptions = "../sdata/05_options.txt" in


flush stdout; flush stderr;
Utils.print "Select TouIST\n";
flush stdout; flush stderr;
let returncode = (command "./touist.exe --version") in
Utils.print "\n";

flush stdout; flush stderr;
if returncode == 0 then Utils.print ""
else begin Utils.eprint "[Error %d] please install TouIST with : brew install touist\n" returncode; exit returncode; end;


let start = Unix.gettimeofday () in 
let contains s1 s2 =
  try
    let len = String.length s2 in
    for i = 0 to String.length s1 - len do
      if String.sub s1 i len = s2 then raise Exit
    done;
    false
  with Exit -> true  in

let rec print_list = function 
  [] -> ()
  | e::l -> print_string e ; print_string " " ; print_list l in


let rec print_numbers oc = function 
  | [] -> ()
  | e::tl -> Printf.fprintf oc "%s\n" e; print_numbers oc tl in  


(* Permutations *)
let rec insert x lst =
  match lst with
  | [] -> [[x]]
  | h::t -> 
    (x::lst) :: (List.map (fun el -> h::el) (insert x t)) in

let rec perm lst =
  match lst with
  | [] -> [lst]
  | h::t -> 
  List.flatten (List.map (insert h) (perm t)) in    
(* End Permutations *)

  let flatten l =
  let rec loop res = function
    | [] -> List.rev res
    | h::t -> loop (List.rev_append h res) t  in
              loop [] l in  

let read_line i = try Some (input_line i) with End_of_file -> None  in
let lines_from_files filename = 
let rec lines_from_files_aux i acc = match (read_line i) with 
        | None -> List.rev acc
        | Some s -> lines_from_files_aux i (s :: acc) in 
        lines_from_files_aux (open_in filename) [] in




        let rec print_numbers oc = function 
        | [] -> ()
        | e::tl -> Printf.fprintf oc "%s\n" e; print_numbers oc tl in  



(*let extract_desire (ls : string) : string =  "-e _" ^opt ^"_ass_"^(String.sub ls ((String.index_from ls 0 '(')+1)  ((String.index_from ls 0 ',' - String.index_from ls 0 '(') - 1))*)
let extract_desire (ls : string) : string =  "-e _" ^opt ^"_ass_"^String.sub ls ((String.rindex_from ls ((String.length ls) - 1) '(') + 1) 3
  in
        
let rec assignment (ls : string list) : string list=
          match ls with
          | [] -> []
          | x :: xs -> (extract_desire x) :: assignment xs  in      


    
        
        
          

let common_files() = 

 
  let assignments_list =  lines_from_files ("../sdata/00_delta0.txt") in 
  let () =
    let preferences = assignment assignments_list in
        (*print_list preferences; *)
        filter_list := (String.concat " " preferences);
        (*Printf.printf "\n%s \n" !filter_list;*)


        (*explanation := lines_from_files "solvedatacp/plan_final_show5b.txt";
        final_explanation :=  String.concat ", " !explanation;*)

        in
       





  let start11 = Unix.gettimeofday () in 
  let string_of_command () =
  (*let tmp_file = "../sdata/00_cp_pre_syntax.txt" in*)
  let tmp_file = "../sdata/00_tempo.txt" in
  (*let _ = Sys.command @@ "grep -F _'"^opt^"'_ "^fileactions^" > solvedatacp/"^opt^"_tmp_actions.txt" in*)
  let _ = Sys.command @@ "grep -e ideal_h_"^opt^" -e _"^opt^"_ass_danger"^" "^(!filter_list)^" "^fileactions^" > solvedatacp/"^opt^"_tmp_actions.txt" in
  let chan = open_in tmp_file in
  close_in chan
  in
  string_of_command() ;



(*
  let start11 = Unix.gettimeofday () in 
  let string_of_command () =
  (*let tmp_file = "../sdata/00_cp_pre_syntax.txt" in*)
  let tmp_file = "../sdata/00_tempo.txt" in
  let _ = Sys.command @@ "grep -F _'"^opt^"'_ "^fileactions^" > solvedatacp/"^opt^"_tmp_actions.txt" in
  let chan = open_in tmp_file in
  close_in chan
  in
  string_of_command() ;
*)  
  



  let string_of_command () =
  let tmp_file = "../sdata/00_tempo.txt" in
  let _ = Sys.command @@ "grep -F _'danger' solvedatacp/"^opt^"_tmp_actions.txt > solvedatacp/"^opt^"_tmp_actions_danger.txt" in
  let chan = open_in tmp_file in
  close_in chan
  in
  string_of_command();

  let string_of_command4 () =
    let tmp_file = "../sdata/00_tempo.txt" in
     (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/)plusa/))=> plusa/g' -e 's/)),/)),[a]/g' -e 's/~/not /g' solvedatacp/formula_%i_%i.txt" !m !i)   in*)
     let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(m,h,//g' -e 's/)//g' solvedatacp/"^opt^"_tmp_actions_danger.txt")   in
     let chan = open_in tmp_file in
     close_in chan
   in
   string_of_command4();  

  (*Printf.eprintf "== solve time GREP === MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start11);  *)


  let tmp_file = "solvedatacp/"^opt^"_tmp_actions_danger.txt" in
  let chan = open_in tmp_file in
  try
    while true do
      action_danger := input_line chan;
    done;
    with End_of_file -> close_in chan; 
  


 



  in




  
if (encoding = 1) then
begin
  Printf.printf "Performing SAT process ...\n";

let plan m opt = 

  (*Printf.printf "Processing Plans of size = %i \n" !m;*)

              (*Generates the common files to both SAT and QBF processes *)
              linesper := perm (lines_from_files ("solvedatacp/"^opt^"_tmp_actions.txt"));
              let reslst2 =  flatten !linesper in


              let precondition action =
                if (contains action "ideal") then "[m]"^action^" and justif_h_"^opt^"_)"
                else if (contains action "_danger_") then "[m]"^action^""
                else "[m]("^action^" and ("^(!action_danger)^" => th_"^(!action_danger)^" ))"  in
            



              let string_of_command4 () =
              let tmp_file = "../sdata/00_tempo.txt" in
              let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(m,h,//g' solvedatacp/"^opt^"_tmp_actions.txt") in
              let chan = open_in tmp_file in
                        close_in chan
                    in
                    string_of_command4(); 

         let () =
          let oc = open_out (Printf.sprintf "solvedatacp/%s_pato_%i.txt" opt !m) in
          print_numbers oc reslst2;
          close_out oc in
          (*Printf.eprintf "== solve time permutations 0  === MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start10);  *)

(**)            let start11 = Unix.gettimeofday () in 


                let string_of_command4 () =
                let tmp_file = "../sdata/00_tempo.txt" in
                let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(m,h,/plusa({2}(/g' solvedatacp/%s_pato_%i.txt" opt !m) in
                let chan = open_in tmp_file in
                          close_in chan
                      in
                      string_of_command4();        

    let lines = ref "" in
    let lines2 = ref "" in
    let action = ref "" in
    let i = ref 1 in
    let tmp_file = Printf.sprintf "solvedatacp/%s_pato_%i.txt" opt !m in
    let chan = open_in tmp_file in
    let j = ref 0 in
    let touistcode2 = ref 0 in
    j := 0;
    try
      while true do
        (*let start = Unix.gettimeofday () in*)
        j := !j + 1;
        action := input_line chan;



        (*lines := !action ^", "^ !lines;*)
        
        let start5 = Unix.gettimeofday () in
        lines := "("^ (precondition !action) ^" and "^ !action ^", "^ !lines;
        lines2 := !action ^"\n"^ !lines2; (* Only consider the operator without the pre-condition this is to show to the final user *)
        (*Printf.eprintf "== solve time precondition assigment === MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start5);*)



        (*Printf.printf "Before going into the IF %s - %i \n\n" !lines !m;*)
        if !j = !m then  begin 
                        (*Printf.printf "DESPUES DEL IF %s - %i \n" !lines !m;*)
                        let start5 = Unix.gettimeofday () in
                        let string_of_command4 () =
                                
                              let tmp_file = "../sdata/00_tempo.txt" in
                              let _ = (*Printf.printf "DESPUES DEL IF 2222 %s %i %i \n" !lines !m !i;*)
                              Sys.command (Printf.sprintf "echo '%s' >> solvedatacp/%s_pato_seq_%i_%i.txt" !lines opt !m !i);  
                              Sys.command (Printf.sprintf "echo '%s' > solvedatacp/%s_plan_final2.txt" !lines2 opt);
                              (*Printf.eprintf "== solve ECHO time: %f sec\n" (Unix.gettimeofday () -. start);*)
                              (*Printf.printf "DESPUES DEL IF 333 %s %i %i \n" !lines !m !i;*) in
                              let chan = open_in tmp_file in
                              close_in chan
                              in
                              string_of_command4();  

                        
                        
                        let string_of_command4 () =
                              let tmp_file = "../sdata/00_tempo.txt" in
                              let _ = Sys.command (Printf.sprintf "sed -i -e 's/]/)/g' -e 's/\[/(/g' -e 's/(m)plusa/[m]/g' -e 's/([m]({2}/([m]/g' solvedatacp/%s_pato_seq_%i_%i.txt" opt !m !i)   in
                              let chan = open_in tmp_file in
                              close_in chan
                              in
                              string_of_command4();  

                              
                        (* Here we generate the Plan formula, putting together the 01_ini_state / 02_actions = pato_seq_%i_%i.txt / 03_goal = 03_goalb.txt*)    
                        let string_of_command5 () =
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = Sys.command (Printf.sprintf "cat %s ../sdata/99_implies.txt solvedatacp/%s_pato_seq_%i_%i.txt ../sdata/99_boxm.txt %s >  solvedatacp/%s_formula_%i_%i.txt" filemodel opt !m !i filegoal opt !m !i)   in 
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command5();  

                            (* Here with close with ")" the seq of plusa operators starting from the inner one *)  
                            for j = 0 to !m do


                              let string_of_command4 () =
                                      
                                      let tmp_file = "../sdata/00_tempo.txt" in
                                      let _ = Sys.command (Printf.sprintf "echo '))' >> solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                      let chan = open_in tmp_file in
                                      close_in chan
                                    in
                                    string_of_command4(); 

                            done;          

                            
                              let string_of_command4 () =                             
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i '1 i\ (not ([m](' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                
                                (*sed -i '1 i\anything' file*)

                                let chan = open_in tmp_file in
                                close_in chan;

                              in
                              string_of_command4(); 


                              let string_of_command4d() =
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i 's/),/,/g' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4d();                                  


                              let string_of_command4e() =
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i '$ s/.$//' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4e();                                


                                let string_of_command4c() =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i 's/{2}(/{2} /g' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4c();  
  

                              (* Here we only replace the {2} by th_ to speed up the process... and that's all*)    

                              let string_of_command4b() =
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i -e 's/{2} /th_/g' -e 's/m](th_/m](/g' -e 's/) and justif_h/ and justif_h/g' -e 's/(plusa(th_/((/g' -e 's/=> plusa(th_/=> (th_/g' -e 's/((m)((/([m]((/g' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4b();  

                                     
                            (*Printf.eprintf "== solve time generacion de plan formula candidate  === MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start5);         *)


(* *)                                    
                              (* Encapsulates the Process Plan procedure *)  
                              let process () =     
                                (*Printf.printf "Testing formula_%i_%i.txt \n" !m !i;*)
                                flush stdout; flush stderr;

                              (* TRANSLATOR generates Prop Logic formula for touist.exe *)    

                              let start2 = Unix.gettimeofday () in 
                              command (Printf.sprintf "./translator.exe --sat solvedatacp/%s_formula_%i_%i.txt" opt !m !i);
                              (*Printf.eprintf "== solve time TRANSLATOR == MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start2);*)
                              let start3 = Unix.gettimeofday () in 
                              touistcode2 := (command (Printf.sprintf "./touist.exe ../sdata/proplogic/%s_formula_%i_%i.txt --solve" opt !m !i));
                              (*Printf.eprintf "== solve time TOUIST === MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start3);*)

                              (*Printf.printf "touistcode ==>  %i \n\n" !touistcode2;*)


                              Printf.printf "Plan_%i_%i_%s.txt \n" !m !i opt;  (*- @@@ *)
                              flush stdout; flush stderr;
                              (*Printf.eprintf "== solve time MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start);*)

                              let start8 = Unix.gettimeofday () in

                              if !touistcode2 = 8 then 

                                 begin
                                    Printf.printf "Plan of size %i found  : \n" !m;
                                    flush stdout; flush stderr;

                                  let string_of_command4b() =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "cat solvedatacp/%s_plan_final2.txt > solvedatacp/plan_final_show.txt" opt)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                  in
                                  string_of_command4b();  


                                  let string_of_command4 () =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "sed -i 's/{2}/{h}/g' solvedatacp/plan_final_show.txt")   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4(); 




                                  let string_of_command4 () =
                                        let tmp_file = "../sdata/00_tempo.txt" in
                                        let _ = Sys.command (Printf.sprintf "cat solvedatacp/plan_final_show.txt > solvedatacp/plan_final_show2.txt")   in
                                        let chan = open_in tmp_file in
                                        close_in chan
                                        in
                                        string_of_command4();                                       

                                  let string_of_command4 () =
                                          let tmp_file = "../sdata/00_tempo.txt" in
                                          let _ = Sys.command (Printf.sprintf "sed -i -e 's/plusa({h}(val_//g' -e 's/_ass_/ /g' -e 's/_/ is /g' -e 's/)//g' solvedatacp/plan_final_show2.txt")   in
                                          let chan = open_in tmp_file in
                                          close_in chan
                                          in
                                          string_of_command4();                                         

                                  let string_of_command4 () =
                                          let tmp_file = "../sdata/00_tempo.txt" in
                                          let _ = Sys.command (Printf.sprintf "cat solvedatacp/plan_final_show2.txt | head -n -2 > solvedatacp/plan_final_show3.txt")   in
                                          let chan = open_in tmp_file in
                                          close_in chan
                                          in
                                          string_of_command4();          
                                          
                                          
                                          let string_of_command4 () =
                                            let tmp_file = "../sdata/00_tempo.txt" in
                                            let _ = Sys.command (Printf.sprintf "cat solvedatacp/plan_final_show2.txt | head -n -2 > solvedatacp/plan_final_show3.txt")   in
                                            let chan = open_in tmp_file in
                                            close_in chan
                                            in
                                            string_of_command4();      







                                          let string_of_command4 () =
                                            let tmp_file = "../sdata/00_tempo.txt" in
                                            let _ = Sys.command (Printf.sprintf "head -n 1 solvedatacp/plan_final_show3.txt > solvedatacp/plan_final_show4.txt")   in
                                            let chan = open_in tmp_file in
                                            close_in chan
                                            in
                                            string_of_command4();       
                                            

                                            let string_of_command4 () =
                                              let tmp_file = "../sdata/00_tempo.txt" in
                                              let _ = Sys.command (Printf.sprintf "tail -n +2 solvedatacp/plan_final_show3.txt > solvedatacp/plan_final_show4b.txt")   in
                                              let chan = open_in tmp_file in
                                              close_in chan
                                              in
                                              string_of_command4();                                                   





                                          let string_of_command4 () =
                                            let tmp_file = "../sdata/00_tempo.txt" in
                                            let _ = Sys.command (Printf.sprintf "awk '{print $1}' solvedatacp/plan_final_show4.txt > solvedatacp/option.out")   in
                                            let chan = open_in tmp_file in
                                            close_in chan
                                            in
                                            string_of_command4();                                         


                                            let string_of_command4 () =
                                              let tmp_file = "../sdata/00_tempo.txt" in
                                              let _ = Sys.command (Printf.sprintf "awk '{print $4}' solvedatacp/plan_final_show4.txt > solvedatacp/option_danger.out")   in
                                              let chan = open_in tmp_file in
                                              close_in chan
                                              in
                                              string_of_command4();                                                 
                                            
  
                                        (* Read the option*)

                                        let tmp_file = "solvedatacp/option.out" in
                                        let chan = open_in tmp_file in
                                        try
                                          while true do
                                            ideal_option := input_line chan;
                                          done;
                                          with End_of_file -> close_in chan; 




                                          let tmp_file = "solvedatacp/option_danger.out" in
                                          let chan = open_in tmp_file in
                                          try
                                            while true do
                                              ideal_option_danger := input_line chan;
                                            done;
                                            with End_of_file -> close_in chan; 
                                            
                                            


                                          let string_of_command4 () =
                                            let tmp_file = "../sdata/00_tempo.txt" in
                                            let _ = Sys.command (Printf.sprintf "sed -i -e 's/%s //g' solvedatacp/plan_final_show4b.txt" !ideal_option)   in
                                            let chan = open_in tmp_file in
                                            close_in chan
                                            in
                                            string_of_command4();                                             


                                            let string_of_command4 () =
                                              let tmp_file = "../sdata/00_tempo.txt" in
                                              let _ = Sys.command (Printf.sprintf "awk 'NR==FNR {h[$1] = $2; next} {print h[$1],$2,$3}' ../sdata/02_actions_translate.txt solvedatacp/plan_final_show4b.txt > solvedatacp/plan_final_show5b.txt")   in
                                              let chan = open_in tmp_file in
                                              close_in chan
                                              in
                                              string_of_command4();                                             


                                            




                   
                                      explanation := lines_from_files "solvedatacp/plan_final_show5b.txt";
                                      final_explanation :=  String.concat ", " !explanation;


                                        if !ideal_option = "te" then ideal_sport:= "tennis";
                                        if !ideal_option = "di" then ideal_sport:= "diving";
                                        if !ideal_option = "so" then ideal_sport:= "soccer";
                                        if !ideal_option = "yo" then ideal_sport:= "yoga";
                                        if !ideal_option = "sq" then ideal_sport:= "squash";
                                        if !ideal_option = "sw" then ideal_sport:= "swimming";
                                        if !ideal_option = "ru" then ideal_sport:= "running";
                                        if !ideal_option = "hr" then ideal_sport:= "horse riding";




                                        
                                        let string_of_command4 () =
                                          let tmp_file = "../sdata/00_tempo.txt" in
                                          let _ = Sys.command (Printf.sprintf "echo 'I found that %s has a %s dangerousness level.' > solvedatacp/final.out" !ideal_sport !ideal_option_danger)   in
                                          let chan = open_in tmp_file in
                                          close_in chan
                                          in
                                          string_of_command4();                                        


                                          let string_of_command4 () =
                                            let tmp_file = "../sdata/00_tempo.txt" in
                                            let _ = Sys.command (Printf.sprintf "echo 'In addition, it satisfies your desires because: ' >> solvedatacp/final.out")   in
                                            let chan = open_in tmp_file in
                                            close_in chan
                                            in
                                            string_of_command4();                                                                                  




                                          let string_of_command4 () =
                                            let tmp_file = "../sdata/00_tempo.txt" in
                                            let _ = Sys.command (Printf.sprintf "echo '%s' >> solvedatacp/final.out" !final_explanation)   in
                                            let chan = open_in tmp_file in
                                            close_in chan
                                            in
                                            string_of_command4();                                        
  


                                            let string_of_command4 () =
                                              let tmp_file = "../sdata/00_tempo.txt" in
                                              let _ = Sys.command (Printf.sprintf "echo 'For all these reasons, I recommend %s as the ideal sport for you ' >> solvedatacp/final.out" !ideal_sport)   in
                                              let chan = open_in tmp_file in
                                              close_in chan
                                              in
                                              string_of_command4();                                               



                                              let string_of_command4 () =
                                                let tmp_file = "../sdata/00_tempo.txt" in
                                                let _ = Sys.command (Printf.sprintf "cat solvedatacp/final.out >> solvedatacp/plan_final_show.txt")   in
                                                let chan = open_in tmp_file in
                                                close_in chan
                                                in
                                                string_of_command4();                                                  


                                        (* Read the option*)
                                     

                                    Printf.eprintf "== solve PLANNER time: %f sec\n" (Unix.gettimeofday () -. start); (*- @@@*)  

                                    exit 0;




                                  end                                
                                else  
                                  begin
                                  let string_of_command4w () =
                                                          
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "cat 'solvedatacp/%s_pato_seq_%i_%i.txt' > solvedatacp/plan_final.txt" opt !m !i)   in
                                    flush stdout; flush stderr;
                                    let chan = open_in tmp_file in
                                    close_in chan
                                  in
                                  string_of_command4w(); 
                                  (*Printf.eprintf "== solve PLANNER - NO PLAN  time: %f sec\n" (Unix.gettimeofday () -. start); (*- @@@*)  *)
                                  end    
                              in
                              process();     
                                

                            i := 1 + !i;
                            j := 0;
                            lines := "";
                            lines2 := "";
                        end

      done;
     
      
        
     with End_of_file -> close_in chan; 
                  
in

(*
let _ = Sys.command (Printf.sprintf "cat 'solvedatacp/%s_pato_seq_%i_%i.txt' > solvedatacp/plan_final.txt" opt !m !i)   in
*)


let start7 = Unix.gettimeofday () in

let returncode = (Sys.command (Printf.sprintf "rm solvedatacp/%s_*.*" sport)) in
let returncode = (Sys.command (Printf.sprintf "rm ../sdata/proplogic/%s_*.*" sport)) in
let returncode = (Sys.command (Printf.sprintf "rm solvedatacp/plan_*.*")) in
let returncode = (Sys.command (Printf.sprintf "rm solvedatacp/*.out")) in


(*Printf.eprintf "== solve time removes === MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start7);*)


(* Lee el archivo decires x fuera y genera el size del Plan y filtra los decires que solo son relevantes, pues se tiene el file de decires 00_base ???, en otras palabras el planer solo encuentra el orden correcto
para el option que es el GOAL, pues las acciones ya estan filtradas *)
(*let pm = ref 0 in
  (*pm := List.length (lines_from_files fileactions);*)
  pm := 7;
  
let px = ref 0 in
  (*for l = 0 to 7 do*)
  (*let sport = (List.nth !lines l) in *)
  Printf.printf "\nTrying with %s \n" sport;
  
  for p = 7 to !pm do
    (*read_file(fileoptions);*)
    px := p;
    plan px sport;
  done;
*)
common_files();
(*psize := (List.length (lines_from_files ("solvedatacp/"^opt^"_tmp_actions.txt"))) + 1;*)
psize := (List.length (lines_from_files ("solvedatacp/"^opt^"_tmp_actions.txt")));
plan psize sport;

(*done;*)

Printf.printf " Plan not found \n";

let string_of_command4b() =
  let tmp_file = "../sdata/00_tempo.txt" in
  let _ = Sys.command (Printf.sprintf "echo 'Sorry, it was not possible to find an ideal sport for you' > solvedatacp/plan_final_show.txt")   in
  let chan = open_in tmp_file in
  close_in chan
  
in
string_of_command4b();  

exit 0;
end;

(*QBF Process*)
(*QBF Process*)

if (encoding = 2) then
begin
  Printf.printf "Performing QBF process ...\n";


  let plan m opt = 

    (*Printf.printf "Processing Plans of size = %i \n" !m;*)
  
                (*Generates the common files to both SAT and QBF processes *)
                
                common_files();
                (* Generates all possible permutations with items in opt_tmp_actions.txt *)
                (*linesper := perm (lines_from_files ("solvedatacp/"^opt^"_tmp_actions.txt"));*)
                linesperx := (lines_from_files ("solvedatacp/"^opt^"_tmp_actions.txt"));
                let reslst2 =  !linesperx in
  

                let selector action =
                  "sel_th_"^action^"_th_"^action  in                


                let precondition action =
                  if (contains action "ideal") then "[m]("^action^" and justif_h_"^opt^"_)"
                  else if (contains action "_danger_") then "[m]("^action^")"
                  else "[m]("^action^" and ("^(!action_danger)^" => th_"^(!action_danger)^" ))"  in
              
                  let string_of_command4 () =
                    let tmp_file = "../sdata/00_tempo.txt" in
                    let _ = Sys.command (Printf.sprintf "cat solvedatacp/"^opt^"_tmp_actions.txt > solvedatacp/"^opt^"_tmp_actions_th.txt") in
                    let chan = open_in tmp_file in
                              close_in chan
                          in
                          string_of_command4();   
                
                  let string_of_command4 () =
                    let tmp_file = "../sdata/00_tempo.txt" in
                    let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(m,h,/th_/g' -e 's/.$//' solvedatacp/"^opt^"_tmp_actions_th.txt") in
                    let chan = open_in tmp_file in
                              close_in chan
                          in
                          string_of_command4(); 

(* Generate the SET 
$Op=[th_ideal_h_te_, th_val_te_ass_env_land, th_val_te_ass_danger_med, th_val_te_ass_loc_mixed, th_val_te_ass_soc_mixed, th_val_te_ass_intens_med]
With the elements of "^opt^"_tmp_actionsb.txt, pienso sacar copia de este archivo e insertar al inicio $Op=[, ]  al final y , al final de c/linea
*)
                  let string_of_command4 () =
                    let tmp_file = "../sdata/00_tempo.txt" in
                    let _ = Sys.command (Printf.sprintf "cat solvedatacp/"^opt^"_tmp_actions_th.txt > solvedatacp/"^opt^"_tmp_actions_set.txt") in
                    let chan = open_in tmp_file in
                                close_in chan
                          in
                          string_of_command4(); 

                  let string_of_command4 () =
                    let tmp_file = "../sdata/00_tempo.txt" in
                    let _ = Sys.command (Printf.sprintf "sed -i -e '1s/^/$Op=[/' -e 's/$/,/' -e '$ s/.$//' -e '$a]' solvedatacp/"^opt^"_tmp_actions_set.txt") in
                    let chan = open_in tmp_file in
                                close_in chan
                          in
                          string_of_command4(); 
        


(* -e 's/$/,/' -e '$ s/.$//' -e '$a]'  *)


  
                (*    
                let string_of_command4 () =
                let tmp_file = "../sdata/00_tempo.txt" in
                let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(m,h,//g' solvedatacp/"^opt^"_tmp_actions.txt") in
                let chan = open_in tmp_file in
                          close_in chan
                      in
                      string_of_command4(); 
                *)
  
           let () =
            let oc = open_out (Printf.sprintf "solvedatacp/%s_pato_%i.txt" opt !m) in
            print_numbers oc reslst2;
            close_out oc in
            (*Printf.eprintf "== solve time permutations 0  === MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start10);  *)
  
  (**)            let start11 = Unix.gettimeofday () in 
  
  
                  let string_of_command4 () =
                  let tmp_file = "../sdata/00_tempo.txt" in
                  (*let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(m,h,/plusa({2}(/g' solvedatacp/%s_pato_%i.txt" opt !m) in*)
                  let _ = Sys.command (Printf.sprintf "sed -i -e 's/inform(m,h,//g' -e 's/.$//g' solvedatacp/%s_pato_%i.txt" opt !m) in
                  let chan = open_in tmp_file in
                            close_in chan
                        in
                        string_of_command4();      
                        
                        
                        
  
      let lines = ref "" in
      let lines2 = ref "" in
      let action = ref "" in
      let i = ref 1 in
      let tmp_file = Printf.sprintf "solvedatacp/%s_pato_%i.txt" opt !m in
      let chan = open_in tmp_file in
      let j = ref 0 in
      let touistcode2 = ref 0 in
      j := 0;
      try
        while true do
          (*let start = Unix.gettimeofday () in*)
          j := !j + 1;
          action := input_line chan;
  
  
  
          (*lines := !action ^", "^ !lines;*)
          
          let start5 = Unix.gettimeofday () in
          lines := "("^(selector !action)^ " => phi(th_"^(!action)^","^(precondition !action)^")) and "^ !lines;
          lines2 := !action ^"\n"^ !lines2; (* Only consider the operator without the pre-condition this is to show to the final user *)
          (*Printf.eprintf "== solve time precondition assigment === MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start5);*)
  
  
  
          (*Printf.printf "Before going into the IF %s - %i \n\n" !lines !m;*)
          if !j = !m then  begin 
                          (*Printf.printf "DESPUES DEL IF %s - %i \n" !lines !m;*)
                          let start5 = Unix.gettimeofday () in
                          let string_of_command4 () =
                                  
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = (*Printf.printf "DESPUES DEL IF 2222 %s %i %i \n" !lines !m !i;*)
                                Sys.command (Printf.sprintf "echo '%s' >> solvedatacp/%s_pato_seq_%i_%i.txt" !lines opt !m !i);  
                                Sys.command (Printf.sprintf "echo '%s' > solvedatacp/%s_plan_final2.txt" !lines2 opt);
                                (*Printf.eprintf "== solve ECHO time: %f sec\n" (Unix.gettimeofday () -. start);*)
                                (*Printf.printf "DESPUES DEL IF 333 %s %i %i \n" !lines !m !i;*) in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4();  
  

                                
                          let string_of_command4 () =
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i -e '1 i\((' -e '$ s/.$//' -e '$ s/.$//' -e '$ s/.$//' -e '$ s/.$//' -e '$a) and' solvedatacp/%s_pato_seq_%i_%i.txt" opt !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4();  

                                (*sed -i '1 i\anything' file*)



                          (*
                          let string_of_command4 () =
                                let tmp_file = "../sdata/00_tempo.txt" in
                                let _ = Sys.command (Printf.sprintf "sed -i -e 's/]/)/g' -e 's/\[/(/g' -e 's/(m)plusa/[m]/g' -e 's/([m]({2}/([m]/g' solvedatacp/%s_pato_seq_%i_%i.txt" opt !m !i)   in
                                let chan = open_in tmp_file in
                                close_in chan
                                in
                                string_of_command4();  
                          *)                                
  
                                
                          (* Here we generate the Plan formula, putting together the 01_ini_state / 02_actions = pato_seq_%i_%i.txt / 03_goal = 03_goalb.txt*)   
                          (* OJO !! Aca hay que incluir el SET OF AXIOMS de los SELECTORS al INICIO DE LA FORMULA !!!!*)   
                          let string_of_command5 () =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  (*let _ = Sys.command (Printf.sprintf "cat %s ../sdata/99_implies.txt solvedatacp/%s_pato_seq_%i_%i.txt ../sdata/99_psi.txt %s >  solvedatacp/%s_formula_%i_%i.txt" filemodel opt !m !i filegoal opt !m !i)   in *)
                                  let _ = Sys.command (Printf.sprintf "cat solvedatacp/%s_tmp_actions_set.txt ../sdata/00_axioms_selectors.txt ../sdata/99_box_inistate.txt %s ../sdata/99_implies.txt solvedatacp/%s_pato_seq_%i_%i.txt ../sdata/99_psi.txt %s >  solvedatacp/%s_formula_%i_%i.txt" opt filemodel opt !m !i filegoal opt !m !i)   in 
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command5();  
  

                              (* Here with close with ")" the seq of plusa operators starting from the inner one *)  
                              for j = 0 to 1 do
                                  let string_of_command4 () =
                                        
                                        let tmp_file = "../sdata/00_tempo.txt" in
                                        let _ = Sys.command (Printf.sprintf "echo '))' >> solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                        let chan = open_in tmp_file in
                                        close_in chan
                                      in
                                      string_of_command4(); 
                              done;          
  
  
                                let string_of_command4d() =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i 's/),/,/g' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4d();                                  
  
  
                                let string_of_command4e() =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i '$ s/.$//' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4e();                                
  
  
                                  let string_of_command4c() =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "sed -i 's/{2}(/{2} /g' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4c();  
    
  
                                (* Here we only replace the {2} by th_ to speed up the process... and that's all*)    
  
                                let string_of_command4b() =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i -e 's/{2} /th_/g' -e 's/m](th_/m](/g' -e 's/) and justif_h/ and justif_h/g' -e 's/(plusa(th_/((/g' -e 's/=> plusa(th_/=> (th_/g' -e 's/((m)((/([m]((/g' solvedatacp/%s_formula_%i_%i.txt" opt !m !i)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4b();  
  
  (* *)                                    
                                (* Encapsulates the Process Plan procedure *)  
                                let process () =     
                                  (*Printf.printf "Testing formula_%i_%i.txt \n" !m !i;*)
                                  flush stdout; flush stderr;
  
                                (* TRANSLATOR generates Prop Logic formula for touist.exe *)    
  
                                let start2 = Unix.gettimeofday () in 
                                (*command (Printf.sprintf "./translator_qbf2.exe solvedatacp/%s_formula_%i_%i.txt" opt !m !i);*)
                                command (Printf.sprintf "./translator.exe --qbf solvedatacp/%s_formula_%i_%i.txt" opt !m !i);
                                (*Printf.eprintf "== solve time TRANSLATOR == MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start2);*)
                                let start3 = Unix.gettimeofday () in 
                                touistcode2 := (command (Printf.sprintf "./touist.exe --qbf ../sdata/proplogic/qbf_%s_formula_%i_%i.txt --solver=rareqs | grep -F '1 sel_' > %s.out" opt !m !i opt));
                                (*Printf.eprintf "== solve time TOUIST === MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start3);*)
                                (*Printf.printf "QBF touistcode2 ==>  %i \n\n" !touistcode2;*)

                                let string_of_command4 () =
                                  let tmp_file = "../sdata/00_tempo.txt" in
                                  let _ = Sys.command (Printf.sprintf "sed -i -e 's/1 sel_th_//g' -e 's/_th_/ /g' %s.out" opt)   in
                                  let chan = open_in tmp_file in
                                  close_in chan
                                  in
                                  string_of_command4(); 


                                  let string_of_command4 () =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    let _ = Sys.command (Printf.sprintf "awk '{print $1}' %s.out  > %s.out2" opt opt)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4();                                   

                                  let string_of_command4 () =
                                    let tmp_file = "../sdata/00_tempo.txt" in
                                    (*let _ = Sys.command (Printf.sprintf "awk '{ tot[$0]++ } END { for (i in tot) print tot[i],i }' %s.out2 | sort -r > %s.out3" opt opt)   in*)
                                    let _ = Sys.command (Printf.sprintf "awk '{ tot[$0]++ } END { for (i in tot) print tot[i],i }' %s.out2 | sort -r > solvedatacp/plan_final_qbf.txt" opt)   in
                                    let chan = open_in tmp_file in
                                    close_in chan
                                    in
                                    string_of_command4(); 
  


                                Printf.printf "Plan_%i_%i_%s.txt \n" !m !i opt;  (*- @@@ *)
                                flush stdout; flush stderr;
                                (*Printf.eprintf "== solve time MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start);*)
  
                                let start8 = Unix.gettimeofday () in
  
                                (*if !touistcode2 = 8 then - Works for SAT -ask Fred is touist return 0 when find a QBF plan ?*)
                                if !touistcode2 = 0 then 
  
                                   begin
                                      (*Printf.printf "Plan of size %i found  : \n" !m;*)
                                      Printf.printf "Plan of size 1 found  : \n"; (* For QBF only one plan*)
                                      flush stdout; flush stderr;
  
                                    let string_of_command4b() =
                                      let tmp_file = "../sdata/00_tempo.txt" in
                                      let _ = Sys.command (Printf.sprintf "cat solvedatacp/%s_plan_final2.txt > solvedatacp/plan_final_show.txt" opt)   in
                                      let chan = open_in tmp_file in
                                      close_in chan
                                    in
                                    string_of_command4b();  
  
  
                                    let string_of_command4 () =
                                      let tmp_file = "../sdata/00_tempo.txt" in
                                      let _ = Sys.command (Printf.sprintf "sed -i 's/{2}/{h}/g' solvedatacp/plan_final_show.txt")   in
                                      let chan = open_in tmp_file in
                                      close_in chan
                                      in
                                      string_of_command4(); 

(*
                                  let string_of_command4 () =
                                        let tmp_file = "../sdata/00_tempo.txt" in
                                        let _ = Sys.command (Printf.sprintf "cat solvedatacp/plan_final_show.txt > solvedatacp/plan_final_show2.txt")   in
                                        let chan = open_in tmp_file in
                                        close_in chan
                                        in
                                        string_of_command4();                                       

                                  let string_of_command4 () =
                                          let tmp_file = "../sdata/00_tempo.txt" in
                                          let _ = Sys.command (Printf.sprintf "sed -i -e 's/plusa({h}(val_//g' -e 's/_ass_/ /g' -e 's/_/ is /g' solvedatacp/plan_final_show2.txt")   in
                                          let chan = open_in tmp_file in
                                          close_in chan
                                          in
                                          string_of_command4();                                         *)
  
  



                                      let string_of_command4 () =
                                        let advice = ref "I found that tennis has a medium dangerousness level. In addition, it satisfies" in
                                        let advice2 = ref "your desires because: the intensity is medium, the sociality is mixed, " in
                                        let advice3 = ref "the location is mixed and the environment is land. For all these reasons" in
                                        let advice4 = ref "I recommend tennis as the ideal sport for you." in
                                        let tmp_file = "../sdata/00_tempo.txt" in
                                        let _ = Sys.command (Printf.sprintf "echo '%s' >> solvedatacp/plan_final_show.txt" !advice) in
                                        let _ = Sys.command (Printf.sprintf "echo '%s' >> solvedatacp/plan_final_show.txt" !advice2) in
                                        let _ = Sys.command (Printf.sprintf "echo '%s' >> solvedatacp/plan_final_show.txt" !advice3) in
                                        let _ = Sys.command (Printf.sprintf "echo '%s' >> solvedatacp/plan_final_show.txt" !advice4) in
                                        let chan = open_in tmp_file in
                                        close_in chan
                                        in
                                        string_of_command4(); 
  
                                      Printf.eprintf "== solve PLANNER time: %f sec\n" (Unix.gettimeofday () -. start); (*- @@@*)  
  
                                      exit 0;
  
  
  
  
                                    end                                
                                  else  
                                    begin
                                    let string_of_command4w () =
                                                            
                                      let tmp_file = "../sdata/00_tempo.txt" in
                                      let _ = Sys.command (Printf.sprintf "cat 'solvedatacp/%s_pato_seq_%i_%i.txt' > solvedatacp/plan_final.txt" opt !m !i)   in
                                      flush stdout; flush stderr;
                                      let chan = open_in tmp_file in
                                      close_in chan
                                    in
                                    string_of_command4w(); 
                                    (*Printf.eprintf "== solve PLANNER - NO PLAN  time: %f sec\n" (Unix.gettimeofday () -. start); (*- @@@*)  *)
                                    end    
                                in
                                process();     
                                  
  
                              i := 1 + !i;
                              j := 0;
                              lines := "";
                              lines2 := "";
                          end
  
        done;
       
        
          
       with End_of_file -> close_in chan; 
                    
  in
  
  (*
  let _ = Sys.command (Printf.sprintf "cat 'solvedatacp/%s_pato_seq_%i_%i.txt' > solvedatacp/plan_final.txt" opt !m !i)   in
  *)
  
  
  let start7 = Unix.gettimeofday () in
  
  let returncode = (Sys.command (Printf.sprintf "rm solvedatacp/%s_*.*" sport)) in
  let returncode = (Sys.command (Printf.sprintf "rm ../sdata/proplogic/%s_*.*" sport)) in
  let returncode = (Sys.command (Printf.sprintf "rm solvedatacp/plan_*.*")) in
  
  
  (*Printf.eprintf "== solve time removes === MAIN.EXE : %f sec\n" (Unix.gettimeofday () -. start7);*)
  
  
  
  let pm = ref 0 in
    (*pm := List.length (lines_from_files fileactions);*)
    pm := 6;
    
  let px = ref 0 in
    (*for l = 0 to 7 do*)
    (*let sport = (List.nth !lines l) in *)
    Printf.printf "\nTrying with %s \n" sport;
    
    for p = 6 to !pm do
      (*read_file(fileoptions);*)
      px := p;
      plan px sport;
    done;
  
  
  (*done;*)
  
  Printf.printf " Plan not found \n";
  
  let string_of_command4b() =
    let tmp_file = "../sdata/00_tempo.txt" in
    let _ = Sys.command (Printf.sprintf "echo 'Sorry, it was not possible to find an ideal sport for you' > solvedatacp/plan_final_show.txt")   in
    let chan = open_in tmp_file in
    close_in chan
    
  in
  string_of_command4b();  
  
  
  
  exit 0;



end; 

end


